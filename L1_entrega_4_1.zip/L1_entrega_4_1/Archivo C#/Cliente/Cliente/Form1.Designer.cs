﻿namespace Cliente
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Function = new System.Windows.Forms.GroupBox();
            this.alto = new System.Windows.Forms.RadioButton();
            this.altura = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.enviar = new System.Windows.Forms.Button();
            this.longitudNombre = new System.Windows.Forms.RadioButton();
            this.nombreBonito = new System.Windows.Forms.RadioButton();
            this.nombre = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.conectar = new System.Windows.Forms.Button();
            this.desconectar = new System.Windows.Forms.Button();
            this.palindromo = new System.Windows.Forms.RadioButton();
            this.nombreMayusculas = new System.Windows.Forms.RadioButton();
            this.Function.SuspendLayout();
            this.SuspendLayout();
            // 
            // Function
            // 
            this.Function.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.Function.Controls.Add(this.nombreMayusculas);
            this.Function.Controls.Add(this.palindromo);
            this.Function.Controls.Add(this.alto);
            this.Function.Controls.Add(this.altura);
            this.Function.Controls.Add(this.label2);
            this.Function.Controls.Add(this.enviar);
            this.Function.Controls.Add(this.longitudNombre);
            this.Function.Controls.Add(this.nombreBonito);
            this.Function.Controls.Add(this.nombre);
            this.Function.Controls.Add(this.label1);
            this.Function.Location = new System.Drawing.Point(30, 70);
            this.Function.Name = "Function";
            this.Function.Size = new System.Drawing.Size(623, 411);
            this.Function.TabIndex = 0;
            this.Function.TabStop = false;
            this.Function.Text = "Function";
            // 
            // alto
            // 
            this.alto.AutoSize = true;
            this.alto.Location = new System.Drawing.Point(107, 181);
            this.alto.Name = "alto";
            this.alto.Size = new System.Drawing.Size(123, 20);
            this.alto.TabIndex = 7;
            this.alto.TabStop = true;
            this.alto.Text = "Dime si soy alto";
            this.alto.UseVisualStyleBackColor = true;
            // 
            // altura
            // 
            this.altura.Location = new System.Drawing.Point(116, 299);
            this.altura.Name = "altura";
            this.altura.Size = new System.Drawing.Size(100, 22);
            this.altura.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(68, 299);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 16);
            this.label2.TabIndex = 5;
            this.label2.Text = "Altura";
            // 
            // enviar
            // 
            this.enviar.Location = new System.Drawing.Point(131, 350);
            this.enviar.Name = "enviar";
            this.enviar.Size = new System.Drawing.Size(75, 23);
            this.enviar.TabIndex = 4;
            this.enviar.Text = "ENVIAR";
            this.enviar.UseVisualStyleBackColor = true;
            this.enviar.Click += new System.EventHandler(this.enviar_Click);
            // 
            // longitudNombre
            // 
            this.longitudNombre.AutoSize = true;
            this.longitudNombre.Location = new System.Drawing.Point(107, 145);
            this.longitudNombre.Name = "longitudNombre";
            this.longitudNombre.Size = new System.Drawing.Size(209, 20);
            this.longitudNombre.TabIndex = 3;
            this.longitudNombre.TabStop = true;
            this.longitudNombre.Text = "Dime la longitud de mi nombre";
            this.longitudNombre.UseVisualStyleBackColor = true;
            // 
            // nombreBonito
            // 
            this.nombreBonito.AutoSize = true;
            this.nombreBonito.Location = new System.Drawing.Point(107, 106);
            this.nombreBonito.Name = "nombreBonito";
            this.nombreBonito.Size = new System.Drawing.Size(197, 20);
            this.nombreBonito.TabIndex = 2;
            this.nombreBonito.TabStop = true;
            this.nombreBonito.Text = "Dime si mi nombre es bonito";
            this.nombreBonito.UseVisualStyleBackColor = true;
            // 
            // nombre
            // 
            this.nombre.Location = new System.Drawing.Point(116, 56);
            this.nombre.Name = "nombre";
            this.nombre.Size = new System.Drawing.Size(238, 22);
            this.nombre.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label1.Location = new System.Drawing.Point(44, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "NOMBRE";
            // 
            // conectar
            // 
            this.conectar.Location = new System.Drawing.Point(30, 22);
            this.conectar.Name = "conectar";
            this.conectar.Size = new System.Drawing.Size(206, 40);
            this.conectar.TabIndex = 1;
            this.conectar.Text = "CONECTAR";
            this.conectar.UseVisualStyleBackColor = true;
            this.conectar.Click += new System.EventHandler(this.conectar_Click);
            // 
            // desconectar
            // 
            this.desconectar.BackColor = System.Drawing.SystemColors.Control;
            this.desconectar.Location = new System.Drawing.Point(30, 487);
            this.desconectar.Name = "desconectar";
            this.desconectar.Size = new System.Drawing.Size(206, 39);
            this.desconectar.TabIndex = 2;
            this.desconectar.Text = "DESCONECTAR";
            this.desconectar.UseVisualStyleBackColor = false;
            this.desconectar.Click += new System.EventHandler(this.desconectar_Click);
            // 
            // palindromo
            // 
            this.palindromo.AutoSize = true;
            this.palindromo.Location = new System.Drawing.Point(107, 222);
            this.palindromo.Name = "palindromo";
            this.palindromo.Size = new System.Drawing.Size(228, 20);
            this.palindromo.TabIndex = 8;
            this.palindromo.TabStop = true;
            this.palindromo.Text = "Dime si mi nombre es palindromo";
            this.palindromo.UseVisualStyleBackColor = true;
            // 
            // nombreMayusculas
            // 
            this.nombreMayusculas.AutoSize = true;
            this.nombreMayusculas.Location = new System.Drawing.Point(107, 262);
            this.nombreMayusculas.Name = "nombreMayusculas";
            this.nombreMayusculas.Size = new System.Drawing.Size(264, 20);
            this.nombreMayusculas.TabIndex = 9;
            this.nombreMayusculas.TabStop = true;
            this.nombreMayusculas.Text = "Devuelveme mi nombre en mayusculas";
            this.nombreMayusculas.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(958, 587);
            this.Controls.Add(this.desconectar);
            this.Controls.Add(this.conectar);
            this.Controls.Add(this.Function);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Function.ResumeLayout(false);
            this.Function.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox Function;
        private System.Windows.Forms.RadioButton longitudNombre;
        private System.Windows.Forms.RadioButton nombreBonito;
        private System.Windows.Forms.TextBox nombre;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button enviar;
        private System.Windows.Forms.Button conectar;
        private System.Windows.Forms.Button desconectar;
        private System.Windows.Forms.TextBox altura;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton alto;
        private System.Windows.Forms.RadioButton palindromo;
        private System.Windows.Forms.RadioButton nombreMayusculas;
    }
}

